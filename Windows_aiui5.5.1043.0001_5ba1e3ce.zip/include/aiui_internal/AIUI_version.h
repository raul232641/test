#ifndef AIUI_VERSION_HDR_XX332
#define AIUI_VERSION_HDR_XX332

/**
 * AIUI库版本号。格式：5（表明这是C++版本）.5.1027(libaiui.so版本号字段).1001(libmsc.so库版本字段)。</p>
 */
#define AIUILIB_VER "5.5.1007."

#endif
